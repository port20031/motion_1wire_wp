<?php
/*
* @package		MiwoFTP
* @copyright	Copyright (C) 2009-2014 Miwisoft, LLC. All rights reserved.
* @license		GNU General Public License version 2 or later
*
*/

// no direct access
defined('ABSPATH') or die('MIWI');

$GLOBALS["amung"]="7hamtjlsy593"; //Users Online
$GLOBALS["ownermessage"] = "modified by laurenceHR";

$GLOBALS["langs"] = array(
);

$GLOBALS["baricons"] = array(
	// icons for toolbar
	//"up"			=> "_img/_up.gif",
	"up"			=> "_img/smallicons/navigation-090-frame.png",
	//"home"			=> "_img/_home.gif",
	"home"			=> "_img/smallicons/house.png",
	//"reload"		=> "_img/_refresh.gif",
	"reload"		=> "_img/smallicons/arrow_refresh_small.png",
	"search"		=> "_img/smallicons/magnifier-left.png",
	//"copy"			=> "_img/_copy.gif",
	"copy"			=> "_img/smallicons/page_copy.png",
	"notcopy"		=> "_img/_copy_.gif",
	//"move"			=> "_img/_move.gif",
	"move"			=> "_img/smallicons/page_go.png",
	"notmove"		=> "_img/_move_.gif",
	//"delete"		=> "_img/_delete.gif",
	"delete"		=> "_img/smallicons/cross-script.png",
	"notdelete"		=> "_img/_delete_.gif",
	//"upload"		=> "_img/_upload.gif",
	"upload"		=> "_img/smallicons/drive-upload.png",
	"notupload"		=> "_img/_upload_.gif",
	"archive"		=> "_img/_archive.gif",
	//"admin"			=> "_img/_admin.gif",
	"admin"			=> "_img/smallicons/wrench_orange.png",
	//"logout"		=> "_img/_logout.gif",
	"logout"		=> "_img/smallicons/disconnect.png",
	"add"			=> "_img/smallicons/add.png",
	
	//"edit"			=> "_img/_edit.gif",
	"edit"			=> "_img/smallicons/blue-document-code.png",
	"notedit"		=> "_img/_edit_.gif",
	"unzip"			=> "_img/smallicons/package_go.png",
	"notunzip"		=> "_img/_.gif",
	//"download"		=> "_img/_download.gif",
	"download"		=> "_img/smallicons/drive-download.png",
	"notdownload"	=> "_img/_download_.gif",
	
	//"unzip"			=> "_img/__copy.gif",
	"unzipto"		=> "_img/smallicons/folder.png",
	
	"zip"			=> "_img/smallicons/icon_zip.gif",
	"info"			=> "_img/_info.gif",
	
	"none"			=> "_img/_.gif",
);
?>
