<?php
/*
* @package		MiwoFTP
* @copyright	Copyright (C) 2009-2014 Miwisoft, LLC. All rights reserved.
* @license		GNU General Public License version 2 or later
*
*/

// no direct access
defined('ABSPATH') or die('MIWI');

$GLOBALS["users"]=array(
	array("admin","9628d0d187029e6337baa86780b2abb6",".","http://localhost",1,"",0x0f,1),
); ?>
